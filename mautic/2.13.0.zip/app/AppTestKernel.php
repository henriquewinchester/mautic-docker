<?php

class AppTestKernel extends AppKernel
{
    /**
     * {@inheritdoc}
     */
    protected function isInstalled()
    {
        return true;
    }
}
